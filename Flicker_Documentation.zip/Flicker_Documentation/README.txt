I am not responsible for translation errors. If you find one, I encourage you to contact me on discord to help fix it.
My discord is; スケート一時的なものです。シオカラーズ永遠です。#6629